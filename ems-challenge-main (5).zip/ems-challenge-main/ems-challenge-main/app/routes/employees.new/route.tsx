import {
  Form,
  useActionData,
  redirect,
  type ActionFunction,
} from "react-router";
import { getDB } from "~/db/getDB";

export const action: ActionFunction = async ({ request }) => {
  const formData = await request.formData();
  const full_name = formData.get("full_name");
  const email = formData.get("email");
  const phone_number = formData.get("phone_number");
  const date_of_birth = formData.get("date_of_birth") as string;
  const job_title = formData.get("job_title");
  const department = formData.get("department");
  const salary = formData.get("salary");
  const start_date = formData.get("start_date") as string;
  const end_date = formData.get("end_date") as string;

  // Validate age
  if (!isValidAge(date_of_birth)) {
    return "Employee must be at least 18 years old.";
  }

  // Validate start and end dates
  if (end_date && new Date(start_date) > new Date(end_date)) {
    return "Start date must be earlier than end date.";
  }

  const db = await getDB();
  await db.run(
    "INSERT INTO employees (full_name, email, phone_number, date_of_birth, job_title, department, salary, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
    [
      full_name,
      email,
      phone_number,
      date_of_birth,
      job_title,
      department,
      salary,
      start_date,
      end_date || null, // Allow empty end date
    ]
  );

  return redirect("/employees");
};

// Function to check if the user is at least 18 years old
function isValidAge(dob: string): boolean {
  const birthDate = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();

  // Check if birthday has occurred this year
  const hasBirthdayPassed =
    today.getMonth() > birthDate.getMonth() ||
    (today.getMonth() === birthDate.getMonth() &&
      today.getDate() >= birthDate.getDate());

  return age > 18 || (age === 18 && hasBirthdayPassed);
}

export default function NewEmployeePage() {
  const errorMessage = useActionData() as string | undefined;

  return (
    <div>
      <h1>Create New Employee</h1>

      {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}

      <Form method="post">
        <div>
          <label htmlFor="full_name">Full Name</label>
          <input type="text" name="full_name" id="full_name" required />
        </div>

        <div>
          <label htmlFor="email">Email</label>
          <input type="email" name="email" id="email" required />
        </div>

        <div>
          <label htmlFor="phone_number">Phone Number</label>
          <input
            type="text"
            name="phone_number"
            id="phone_number"
            pattern="\d{2} \d{3} \d{3}"
            title="Format: 12 345 678"
            required
          />
        </div>

        <div>
          <label htmlFor="date_of_birth">Date of Birth</label>
          <input type="date" name="date_of_birth" id="date_of_birth" required />
        </div>

        <div>
          <label htmlFor="job_title">Job Title</label>
          <input type="text" name="job_title" id="job_title" required />
        </div>

        <div>
          <label htmlFor="department">Department</label>
          <input type="text" name="department" id="department" required />
        </div>

        <div>
          <label htmlFor="salary">Salary</label>
          <input type="number" name="salary" id="salary" required />
        </div>

        <div>
          <label htmlFor="start_date">Start Date</label>
          <input type="date" name="start_date" id="start_date" required />
        </div>

        <div>
          <label htmlFor="end_date">End Date</label>
          <input type="date" name="end_date" id="end_date" />
        </div>

        <button type="submit">Create Employee</button>
      </Form>

      <hr />
      <ul>
        <li>
          <a href="/employees">Employees</a>
        </li>
        <li>
          <a href="/timesheets">Timesheets</a>
        </li>
      </ul>
    </div>
  );
}
