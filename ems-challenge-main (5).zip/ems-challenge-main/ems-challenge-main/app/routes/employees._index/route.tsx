import { useLoaderData } from "react-router";
import { Link } from "react-router-dom";
import { useState } from "react";
import { getDB } from "~/db/getDB";

export async function loader() {
  const db = await getDB();
  const employees = await db.all(
    "SELECT id, full_name, email, phone_number, job_title FROM employees;"
  );
  return { employees };
}

interface Employee {
  id: number;
  full_name: string;
  email: string;
  phone_number?: string;
  job_title: string;
}

export default function EmployeesPage() {
  const { employees } = useLoaderData();
  const [searchTerm, setSearchTerm] = useState("");
  const [sortField, setSortField] = useState("full_name");
  const [sortOrder, setSortOrder] = useState("asc");

  const filteredEmployees = employees
    .filter((employee: Employee) =>
      employee.full_name.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a: Employee, b: Employee) => {
      const fieldA = a[sortField as keyof Employee];
      const fieldB = b[sortField as keyof Employee];

      if (typeof fieldA === "string" && typeof fieldB === "string") {
        return sortOrder === "asc"
          ? fieldA.localeCompare(fieldB)
          : fieldB.localeCompare(fieldA);
      } else if (typeof fieldA === "number" && typeof fieldB === "number") {
        return sortOrder === "asc" ? fieldA - fieldB : fieldB - fieldA;
      }
      return 0;
    });

  const handleSort = (field: keyof Employee) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
  };

  return (
    <div>
      <h1>Employees List</h1>
      <input
        type="text"
        placeholder="Search employees..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <table border={1}>
        <thead>
          <tr>
            <th onClick={() => handleSort("id")}>ID</th>
            <th onClick={() => handleSort("full_name")}>Full Name</th>
            <th onClick={() => handleSort("email")}>Email</th>
            <th onClick={() => handleSort("phone_number")}>Phone Number</th>
            <th onClick={() => handleSort("job_title")}>Job Title</th>
            <th>View</th>
          </tr>
        </thead>
        <tbody>
          {filteredEmployees.map((employee: Employee) => (
            <tr key={employee.id}>
              <td>{employee.id}</td>
              <td>{employee.full_name}</td>
              <td>{employee.email}</td>
              <td>{employee.phone_number}</td>
              <td>{employee.job_title}</td>
              <td>
                <Link to={`/employees/${employee.id}`}>View</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <hr />
      <ul>
        <li>
          <Link to="/employees/new">New Employee</Link>
        </li>
        <li>
          <Link to="/timesheets/">Timesheets</Link>
        </li>
      </ul>
    </div>
  );
}
