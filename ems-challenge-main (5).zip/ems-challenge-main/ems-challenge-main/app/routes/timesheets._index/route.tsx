import { useLoaderData, Link } from "react-router";
import { useState, useEffect } from "react";
import { getDB } from "~/db/getDB";
import { useCalendarApp, ScheduleXCalendar } from "@schedule-x/react";
import {
  createViewDay,
  createViewMonthAgenda,
  createViewMonthGrid,
  createViewWeek,
} from "@schedule-x/calendar";
import { createEventsServicePlugin } from "@schedule-x/events-service";
import "@schedule-x/theme-default/dist/index.css";

export async function loader() {
  const db = await getDB();
  const timesheetsAndEmployees = await db.all(
    "SELECT timesheets.*, employees.full_name, employees.id AS employee_id FROM timesheets JOIN employees ON timesheets.employee_id = employees.id"
  );

  // Convert date format to ISO 8601 and ensure military time format
  const formattedTimesheets = timesheetsAndEmployees.map((timesheet) => ({
    ...timesheet,
    start_time: new Date(timesheet.start_time).toISOString(), // Ensure ISO format
    end_time: new Date(timesheet.end_time).toISOString(),
  }));

  console.log("Fetched timesheets:", formattedTimesheets); // Debugging

  return { timesheetsAndEmployees: formattedTimesheets };
}

export default function TimesheetsPage() {
  const { timesheetsAndEmployees } = useLoaderData();
  const [isTableView, setIsTableView] = useState(true);
  const [events, setEvents] = useState([]);

  useEffect(() => {
    // Convert timesheets data into calendar event format with military time
    const formattedEvents = timesheetsAndEmployees.map((timesheet) => ({
      id: timesheet.id.toString(),
      title: timesheet.full_name, // Display employee name as event title
      start: timesheet.start_time, // Ensure this is in ISO format
      end: timesheet.end_time,
      allDay: false,
    }));

    console.log("Formatted events:", formattedEvents); // Debugging
    setEvents(formattedEvents);
  }, [timesheetsAndEmployees]);

  const eventsService = useState(() => createEventsServicePlugin())[0];
  const calendar = useCalendarApp({
    views: [
      createViewDay(),
      createViewWeek(),
      createViewMonthGrid(),
      createViewMonthAgenda(),
    ],
    events,
    plugins: [eventsService],
  });

  return (
    <div>
      <div>
        <button onClick={() => setIsTableView(true)}>Table View</button>
        <button onClick={() => setIsTableView(false)}>Calendar View</button>
      </div>

      {isTableView ? (
        <div>
          <h1>Timesheets List</h1>
          <table border={1}>
            <thead>
              <tr>
                <th>ID</th>
                <th>Employee</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>View</th>
              </tr>
            </thead>
            <tbody>
              {timesheetsAndEmployees.map((timesheet) => (
                <tr key={timesheet.id}>
                  <td>{timesheet.id}</td>
                  <td>{timesheet.full_name}</td>
                  <td>
                    {new Date(timesheet.start_time).toLocaleTimeString("en-GB")}
                  </td>
                  <td>
                    {new Date(timesheet.end_time).toLocaleTimeString("en-GB")}
                  </td>
                  <td>
                    <Link to={`/timesheets/${timesheet.id}`}>View</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div>
          <h1>Timesheets Calendar</h1>
          <ScheduleXCalendar calendarApp={calendar} />
        </div>
      )}

      <hr />
      <ul>
        <li>
          <Link to="/timesheets/new">New Timesheet</Link>
        </li>
        <li>
          <Link to="/employees">Employees</Link>
        </li>
      </ul>
    </div>
  );
}
