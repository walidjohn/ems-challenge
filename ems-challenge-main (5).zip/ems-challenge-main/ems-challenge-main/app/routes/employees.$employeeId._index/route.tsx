import { useLoaderData } from "react-router";
import { getDB } from "~/db/getDB";
import type { LoaderFunctionArgs } from "react-router";

export async function loader({ params }: LoaderFunctionArgs) {
  const db = await getDB();
  const employee = await db.get("SELECT * FROM employees WHERE id = ?", [
    params.employeeId,
  ]);

  if (!employee) throw new Response("Not Found", { status: 404 });

  return { employee };
}

export default function EmployeePage() {
  const { employee } = useLoaderData();

  return (
    <div>
      <h1>{employee.full_name}</h1>
      <p>Email: {employee.email}</p>
      <p>Phone: {employee.phone_number}</p>
      <p>Date of Birth: {employee.date_of_birth}</p>
      <p>Job Title: {employee.job_title}</p>
      <p>Department: {employee.department}</p>

      <ul>
        <li>
          <a href="/employees">Employees</a>
        </li>
        <li>
          <a href="/employees/new">New Employee</a>
        </li>
        <li>
          <a href="/timesheets/">Timesheets</a>
        </li>
      </ul>
    </div>
  );
}
