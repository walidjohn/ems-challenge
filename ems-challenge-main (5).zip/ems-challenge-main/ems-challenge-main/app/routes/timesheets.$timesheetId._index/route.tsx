import { useLoaderData, Link } from "react-router";
import { getDB } from "~/db/getDB";

export async function loader({ params }) {
  const db = await getDB();
  const timesheet = await db.get(
    "SELECT timesheets.*, employees.full_name, employees.email FROM timesheets JOIN employees ON timesheets.employee_id = employees.id WHERE timesheets.id = ?",
    [params.timesheetId]
  );

  if (!timesheet) throw new Response("Not Found", { status: 404 });

  return { timesheet };
}

export default function TimesheetDetailsPage() {
  const { timesheet } = useLoaderData();

  return (
    <div>
      <h1>Timesheet #{timesheet.id}</h1>
      <p>
        <strong>Employee:</strong> {timesheet.full_name} ({timesheet.email})
      </p>
      <p>
        <strong>Start Time:</strong> {timesheet.start_time}
      </p>
      <p>
        <strong>End Time:</strong> {timesheet.end_time}
      </p>

      <ul>
        <li>
          <Link to="/timesheets">Timesheets</Link>
        </li>
        <li>
          <Link to="/employees">Employees</Link>
        </li>
        <li>
          <Link to="/employees/new">New Employee</Link>
        </li>
      </ul>
    </div>
  );
}
